#include<stdio.h>
#include<stdlib.h>
int main()
{
	printf("\t    *		\n");
	printf("\t   ***	\n");
	printf("\t  *****	\n");
	printf("\t *******	\n");
	printf("\t*********	\n");

	printf("\n");

	printf("\t    *		\n \
\t   ***	\n \
\t  *****	\n \
\t *******	\n \
\t*********	\n");



	system("pause");
	return 0;
}