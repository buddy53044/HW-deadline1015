#include <stdio.h>
//#include <stdlib.h>

int main()
{
	printf("S    SSSSSS \n");
	printf("S    S    S \n");
	printf("S    S    S \n");
	printf("S    S    S \n");
	printf("SSSSSS    S \n");
	printf("\n");

	printf("RRRRRRRRRRR \n");
	printf("    RR    R \n");
	printf("  R  R    R \n");
	printf("R    R    R \n");
	printf("R    RRRRRR \n");
	printf("\n");

	printf("EEEEEEEEEEE \n");
	printf("E    E    E \n");
	printf("E    E    E \n");
	printf("E    E    E \n");
	printf("E    E    E \n");
	//system("pause");
	return 0;
}